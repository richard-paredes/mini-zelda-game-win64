import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class zeldaGame extends PApplet {


/*
//Controls to play//
  Up, down, left, right: move
  (hold) Spacebar: attack
  (hold) Shift: shield
  v or V: throw boomerang
  A or a: switch to wooden weapon
  B or b: switch to steel weapon
////////////
*/


Minim minim;


int gameScreen; //0 = main menu, 1 = play, 2 = game over
int ticks = 0;
AudioPlayer intro, overworld, gameover, ending, win;
AudioPlayer currentSong;

Button start, restart;


Animation startScreen;
Animation restartScreen;
Animation reverseRestartScreen;
Animation winScreen, winBackground;

Heirarchy heirarchy;
PImage triforce;
PImage logo;
PImage woodSword, whiteSword;
PFont zeldaFont;

int time = millis();

Link link;
int spawnX = 500;
int spawnY = 500;

Map map;
int numScenes = 3;


public void setup() {
  
  
  //load screen data
  frameRate( 10 );
  zeldaFont = createFont("HyliaSerifBeta-Regular.otf", 30);
  textFont(zeldaFont, 32);
  //start
  logo = loadImage("./start/zelda2.gif");
  startScreen = new Animation("./start/start", 8);
  start = new Button(width/2, height*3.5f/5, "START");
  //restart
  restartScreen = new Animation("./gameover/gameover/gameover0/gameover", 51, 3);
  restart = new Button(width/2, height/2, "CONTINUE?");
  reverseRestartScreen = new Animation("./gameoverreverse/gameoverreverse", 63, 3);
  //win
  winScreen = new Animation("./win/link/link", 60, 2);
  winBackground = new Animation("./win/background/win", 4, 2);
  
  map = new Map(numScenes); //3 scenes so far
  triforce = loadImage("triforce.png");
  heirarchy = new Heirarchy(width/2-100,50);
  minim = new Minim(this);
  //load sound
  intro = minim.loadFile("./sound/intro.mp3");
  overworld = minim.loadFile("./sound/overworld.mp3");
  gameover = minim.loadFile("./sound/gameover.mp3");
  ending = minim.loadFile("./sound/ending.mp3");
  win = minim.loadFile("./sound/victory.mp3");
  
  woodSword= loadImage("./sprites/items/woodSword.gif");
  whiteSword=loadImage("./sprites/items/whiteSword.gif");
  
}

public void draw() {
  
  if (gameScreen == 0) {
    frameRate(8);
    mainMenu();
    heirarchy.move();
    heirarchy.display();
  } else if (gameScreen == 1) {
    frameRate(60);
    play();
    if (link.isDead()){
      gameScreen = 2;
      ticks = 0;
      map = new Map(numScenes);
      overworld.pause();
      overworld.rewind();
    }
  }else if (gameScreen == 2) {
    frameRate(60);
    gameOver();
  } else if (gameScreen == 3) {
    frameRate(60);
    win();
  }
}

public void introFade(int c) {
  
  ticks += 1;
  int passedMillis = millis() - time;
  // where "tinting" happens
  if ((passedMillis >= 200)) {
    time = millis();
    fill(c);
    image(triforce, 0, -200);
  }
  rect(0, 0, width, height);
  fill(255, 255, 255, 100);
  delay(150);
    
}


public void fade(int c) {
  
  ticks += 1;
  int passedMillis = millis() - time;
  if ((passedMillis >= 200)) {
    time = millis();
    fill (c);
  }
  rect(0, 0, width, height);
  fill(255, 255, 255, 100);
  delay(150);
    
}

public void mainMenu() {
  if (!intro.isPlaying()){
    intro.loop();
    currentSong = intro;
  }
  textAlign(CENTER);
  
  startScreen.display(0,0, width, height);
  imageMode(CENTER); 
  if (ticks < 11) {
    
    ticks++;
    textSize(100);
    fill(0xffffd80d);
    //text("-ZELDA- LINK", width/2, 0 + (width/2.5 / 11) * ticks);
    // original zelda logo!!!
    image(logo, width/2, 0 + (width/2.5f / 11) * ticks, 450, 250);
  } else {
    textSize(100);
    fill(0xffffd80d);
    strokeWeight(10);
    stroke(0xffffd80d);
    image(logo, width/2, 0 + (width/2.5f / 11) * ticks, 450, 250);
    line(width/2 - 250, height/2 -35, width/2 + 250, height/2 -35);
    //text("-ZELDA- LINK", width/2, 0 + (width/2.5 / 11) * ticks);
  }
  imageMode(CORNER);
  noFill();
  noStroke();
  start.display();
}

public void play() {
  
  if (ticks < 11) {
    introFade(color(0xff6eab43, 200));
  } else {
    if (!overworld.isPlaying()){
      overworld.loop();
      currentSong = overworld;
    }
    map.loadScene();
    map.render();
    // displays the swords
    image(this.woodSword,410,50);
    image(this.whiteSword,495,50);
    
    link.update(map);
    link.display();
  }
  if (link.hasWon()) {
    overworld.pause();
    overworld.rewind();
    gameScreen = 3;
    ticks = 0;
    map = new Map(numScenes);
    win();
  }
  
}

public void gameOver() {
  // flash red before game over screen
  if (ticks < 17) {
    
    if (!gameover.isPlaying()){
      gameover.play();
      currentSong = gameover;
    }
    fade(color(139, 0, 0, 150));
  } else {
    // stop flashing-red song
    if (gameover.isPlaying()){
      gameover.pause();
      gameover.rewind();
    }
    // ending is happening
    if (!ending.isPlaying()){
      ending.loop();
      currentSong = ending;
    }
    fill(0);
    // play the heart-shatter animation only once
    restartScreen.playOnce(0, 0, width, height);
    // check if animation finished playing
    if (restartScreen.hasPlayed) {
      // cover the screen in black to hide previous animation
      rect(0, 0, width, height);
      restartScreen.frame = 0;
      // display the continue button once animation finishes
      if (!reverseRestartScreen.isPlaying) {
        restart.display();
      } 
      // if mouse is pressed, want to reverse the heart shatter once
      else {
        reverseRestartScreen.playOnce(0, 0, width, height);
        //once its reverse, restart to main menu
        if (reverseRestartScreen.hasPlayed) {
          restartScreen.hasPlayed = false;
          reverseRestartScreen.hasPlayed = false;
          gameScreen = 0;
          ticks = 0;
          map = new Map(numScenes);
          ending.pause();
          ending.rewind();
          
        }
      }
    }
  }
  
}

public void win() {
  if (!win.isPlaying()){
    win.loop();
    currentSong = win;
  } if (ticks < 11) {
    introFade(color(0xffffd80d, 100));
  } else {
    textSize(100);
    fill(0);
    rect(0,0,width,height);
    fill(0xffffd80d);
    winBackground.display(0, 0, width, height);
    //fill(34,139,34);
    imageMode(CENTER);
    image(triforce, width/2, height/3.25f, 500, 500);
    winScreen.display(width/2, height*0.70f, 300, 300);
    imageMode(CORNER);
    text("CONGRATULATIONS", width/2, 100);
    fill(255);
    textSize(60);
    text("PRESS ENTER", width/2, height-60);
    text("TO CONTINUE", width/2, height);
    noStroke();
    noFill();
  }
}

public void mousePressed() {
  if ((gameScreen == 0) && (start.isInside())){
    gameScreen = 1;
    ticks = 0;
    map.loadScene();
    
    link = new Link(spawnX, spawnY);
    intro.pause();
    intro.rewind();
  } 
  // used to go to lose screen immediately
  //else if ((gameScreen == 1)) {
  //  gameScreen = 2;
  //  ticks = 0;
  //  overworld.pause();
  //  overworld.rewind();
  //} 
  
  else if ((gameScreen == 2) && (ticks == 17)){
    if (restart.isInside()) {
 
      reverseRestartScreen.playOnce(0, 0, width, height);      
    }
  } else if (gameScreen == 3) {
    win.pause();
    win.rewind();
    gameScreen = 0;
    ticks = 0;
    map = new Map(numScenes);
  }
  
}

public void keyPressed() {
  if (key == 'm' || key == 'M' ) {
    
    if (!currentSong.isMuted()) { currentSong.mute();}
    else { currentSong.unmute();}
    
  }
  
  if (gameScreen == 1) {
    if (keyCode == SHIFT) {
      link.shield(map);
      link.isShielding();
    }
    if (keyCode == UP){
      link.isWalking();
      link.direction = "up";
      link.up(map);
      
    } else if (keyCode == DOWN) {
      link.isWalking();
      link.direction = "down";
      link.down(map);
    
    } else if (keyCode == LEFT) {
      link.isWalking();
      link.direction = "left";
      link.left(map);
      
    } else if (keyCode == RIGHT) {
      link.isWalking();
      link.direction = "right";
      link.right(map);
      
    } else if (key == ' '){
      // cannot stay invulnerable while attacking!
      if (link.isShielding) {
        link.unshield();
        map.removeShieldObstacles();
        link.hasShielded = false;
        link.isShielding = false;
      }
      link.isAttacking(); //used to animate attack
      link.attack(map); //used to detect enemies hit
    
    } else if (key == 'a' || key == 'A'){
      if (link.weapon=="default"){
        link.weapon="steel";
      }
    
    } else if (key == 'b' || key == 'B') {
      if (link.weapon=="steel"){
        link.weapon="default";
        }       
    } else if (key == 'v' || key == 'V') {
      if (link.isShielding) {
        link.unshield();
        map.removeShieldObstacles();
        link.hasShielded = false;
        link.isShielding = false;
      }
      link.throwBoomerang();
    }
  } else if (gameScreen == 3) {
    if (keyCode == ENTER) {
      win.pause();
      win.rewind();
      gameScreen = 0;
      ticks = 0;
      map = new Map(numScenes);
    }
  }
}

public void keyReleased() {
  if (gameScreen == 1) {
    link.isAttacking = false;
    if (key == ' ') {
      link.attackAni.count = 0;
      map.removeAttackObstacles();
      link.hasAttacked = false;
    }
    if (keyCode == SHIFT) {
      link.unshield();
      map.removeShieldObstacles();
      link.hasShielded = false;
      link.isShielding = false;
    }
    if (keyCode == LEFT || keyCode == RIGHT ||keyCode == UP||keyCode == DOWN) {
      link.isWalking = false;
    }
  } 
  
}
// Class for animating a sequence of GIFs

class Animation {
  PImage[] images;
  int imageCount;
  int frame;
  int count=0;
  boolean hasPlayed, isPlaying;
  
  Animation(String imagePrefix, int count) {
    imageCount = count;
    images = new PImage[imageCount];
    this.hasPlayed = false;
    for (int i = 0; i < imageCount; i++) {
      // Use nf() to number format 'i' into four digits
      String filename = imagePrefix + nf(i) + ".gif";
      images[i] = loadImage(filename);
    }
  }
  
  Animation(String imagePrefix, int count, int f) {
    imageCount = count;
    images = new PImage[imageCount];

    for (int i = 0; i < imageCount; i++) {
      // Use nf() to number format 'i' into four digits
      String filename = imagePrefix + nf(i, f) + ".gif";
      images[i] = loadImage(filename);
    }
  }

  public void display() {
    image(images[frameCount%imageCount], 0, 0);
  }
  
  public void display(float xpos, float ypos) {
    count++;
    if (count==15){
      frame = (frame+1) % imageCount;
      count=0;
    }
    
    image(images[frame], xpos, ypos);
    
  }
  
  public void display(float xpos, float ypos, float w, float h) {
    image(images[frameCount%imageCount], xpos, ypos, w, h);
    
  }
  
  public void playOnce(float xpos, float ypos, float w, float h) {
    isPlaying = true;
    frame +=2 ;
    if (!hasPlayed) {
      image(images[(frame)%imageCount], xpos, ypos, w, h);
    }
    if (frame > imageCount - 2) {
      isPlaying = false;
      hasPlayed = true;
      frame = 0;
    }
  }
  
  public int getWidth() {
    return images[0].width;
  }
}
class Attack extends Obstacle {
  String type;  
  Attack(PVector[] position, String attackType) {
    super(position);
    this.type = attackType;
  }
  
}
class Boomerang extends Attack {
  PImage boomerang;
  float boomerangRange, boomerangX, boomerangDX, boomerangY, boomerangDY, rotationalSpeed;
  PVector startingPosition;
  String direction;
  int boomerangWidth = 15; 
  int boomerangHeight = 20;
  
  Boomerang(PVector[] position, String boomerangType, String direction) {
    
    super(position, boomerangType); 
    
    this.startingPosition = position[0].copy();
    this.boomerang = loadImage("./sprites/items/magicboomerang.gif");
    this.boomerang.resize(boomerangWidth, boomerangHeight);
    
    this.direction = direction;
    setBoomerangSpeeds();
    this.boomerangRange = 150;
    this.rotationalSpeed = 0.1f;
    
  }
  public void display() {
    
    PShape obstacle;
    obstacle = createShape();
    obstacle.beginShape();
    obstacle.fill(34,139,34, 200);
    for (int vertex = 0; vertex < this.vertices.length; vertex++) {
      obstacle.vertex(vertices[vertex].x, vertices[vertex].y);
    }
    obstacle.endShape(CLOSE);
    shape(obstacle, 0, 0);
  }
  
  public void setBoomerangSpeeds() {
    this.boomerangDX = 0;
    this.boomerangDY = 0;
    
    if (direction.equals("up")) {
      this.boomerangDY = -5;
    } else if (direction.equals("down")) {
      this.boomerangDY  = 5;
    } else if (direction.equals("left")) {
      this.boomerangDX = -5;
    } else {
      this.boomerangDX = 5;
    }
    
  }
  
  public void updateBoomerangPosition() {
    
    if (direction.equals("down")) {
      //vertices[0].y += boomerangDY;
      for (PVector coord : this.vertices) {
        coord.add(0, boomerangDY);
      }
      if (vertices[0].y > boomerangRange + startingPosition.y) {
        boomerangDY *= -1;
      }
      //check if boomerang should go right or left
    }
    
    else if (direction.equals("up")) {
      //vertices[0].y += boomerangDY;
      for (PVector coord : this.vertices) {
        coord.add(0, boomerangDY);
      }
      if (vertices[0].y < startingPosition.y - boomerangRange) {
        boomerangDY *= -1;
      }
    } 
    
    else if (direction.equals("left")) {
      //vertices[0].x += boomerangDX;
      for (PVector coord : this.vertices) {
        coord.add(boomerangDX, 0);
      }
      if (vertices[0].x < startingPosition.x - boomerangRange) {
        boomerangDX *= -1;
      }
    } 
    
    else {
      //vertices[0].x += boomerangDX;
      for (PVector coord : this.vertices) {
        coord.add(boomerangDX, 0);
      }
      if (vertices[0].x > boomerangRange + startingPosition.x) {
        boomerangDX *= -1;
      }
    }
    
  }
  
  public boolean hasReturned() {
    if (direction.equals("up")) {
      return (vertices[0].y > startingPosition.y);
    } else if (direction.equals("down")) {
      return (vertices[0].y < startingPosition.y);
    } else if (direction.equals("left")) {
      return (vertices[0].x > startingPosition.x);
    } else {
      return (vertices[0].x < startingPosition.x);
    }
  }
  
  public void displayBoomerang() {
    //display();
    rotationalSpeed += 0.2f;
    imageMode(CENTER);
    pushMatrix();
    translate(vertices[0].x + boomerangWidth*1.25f, vertices[0].y + boomerangHeight*0.65f);
    rotate(rotationalSpeed);
    image(boomerang, 0, 0);
    popMatrix();    
    imageMode(CORNER);
  }
}
class Border extends Obstacle {
  int sceneToLoad;
  
  Border(PVector[] vertices, int sceneToLoad) {
    super(vertices);
    this.sceneToLoad = sceneToLoad;
  }
  
  public int getNextScene() {
    return sceneToLoad;
  }
  
}

class Button {
  
  float x, y, w, h;
  String text;
  int col;
  
  Button(float x, float y, String text) {
    this.col = color(255, 255, 255); 
    this.x = x;
    this.y = y;
    this.w = 200;
    this.h = 100;
    this.text = text;
    
  }
  
  public void display() {
    //fill(col);
    noFill();
    //stroke(255);
    noStroke();
    //strokeWeight(2);
    rectMode(CENTER);
    rect(x, y, w, h, 255);
    
    fill(this.col);
    textAlign(CENTER);
    textSize(50);
    text(text, x, y+20);
    
    rectMode(LEFT);
  }
    
  public boolean isInside() {
    if (mouseX >= x-w/2 && mouseX <= x+w/2
    && mouseY <= y+w/2 && mouseY >= y-w/2){      
      return true;
    }
    return false;
  }
  
}
class Enemy {
  float health, move=random(1,5);
  int count=0, index=0, increment=1, invFrame, invulnerabilityFrames;
  boolean tookDamageRecently, markedDead;
  PImage upIdle, downIdle, leftIdle, rightIdle, image;
  Animation enemyUp, enemyDown, enemyLeft, enemyRight, enemyAnimate;
  String enemyType;
  float w, h, spriteSize = 30;
  float x, y;
  
  
  // takes in terrain data so it doesn't spawn on them
  Enemy(ArrayList<Obstacle> obstacles, ArrayList<Border> borders, ArrayList<Enemy> enemies, String enemyType){
    this.x = random(spriteSize, width-spriteSize);
    this.y = random(spriteSize, height-spriteSize);  
    spawn(obstacles, borders, enemies);
    
    this.enemyType = enemyType;
    
    if (this.enemyType=="blueOktorok"){
      this.enemyUp = new Animation("./sprites/enemies/OktorokUp", 2);
      this.enemyDown = new Animation("./sprites/enemies/OktorokDown", 2);
      this.enemyLeft = new Animation("./sprites/enemies/OktorokLeft", 2);
      this.enemyRight = new Animation("./sprites/enemies/OktorokRight", 2);
      this.enemyAnimate = this.enemyUp;
      this.health = 500;
      this.image = this.downIdle;
    }
    else if (this.enemyType=="redOktorok"){
      this.enemyUp = new Animation("./sprites/enemies/OktorokUpRed", 2);
      this.enemyDown = new Animation("./sprites/enemies/OktorokDownRed", 2);
      this.enemyLeft = new Animation("./sprites/enemies/OktorokLeftRed", 2);
      this.enemyRight = new Animation("./sprites/enemies/OktorokRightRed", 2);
      this.enemyAnimate = this.enemyUp;
      this.health = 1000;
      this.image = this.downIdle;
    }
    else if (this.enemyType=="moblin"){
      this.enemyUp = new Animation("./sprites/enemies/moblinUp", 2);
      this.enemyDown = new Animation("./sprites/enemies/moblinDown", 2);
      this.enemyLeft = new Animation("./sprites/enemies/moblinLeft", 2);
      this.enemyRight = new Animation("./sprites/enemies/moblinRight", 2);
      this.enemyAnimate = this.enemyUp;
      this.health = 1500;
      this.image = this.downIdle;
    }
    this.tookDamageRecently = false; 
    this.invFrame = 0;
    this.invulnerabilityFrames = 2;
  }
  
    
  public void update(ArrayList<Attack> attacks, ArrayList<Boomerang> boomerangs) {
    PVector[] currentPosition = getPosition();
    if (collidingWithAttack(attacks, currentPosition)) {
      takeDamage(attacks.get(0).type);
    } 
    if (collidingWithBoomerang(boomerangs, currentPosition)) {
      println("hit an enemy");
      takeDamage(boomerangs.get(0).type);
    }
  }
  
  public boolean isDead() {
    return this.health <= 0;
  }
  
  public void markDead() {
    this.markedDead = true;
  }
  
  public void takeDamage(String attackType) {
    
    if (!tookDamageRecently){
      if (attackType.equals("default")) {
        
        // wood deals less to moblins but more to oktorok
        if (this.enemyType.equals("moblin")) {
          this.health -= 1;
        } else {
          this.health -= 25;
        }
      } else if (attackType.equals("steel")) {
        // steel deals more damage to moblins but less to oktorok
        if (this.enemyType.equals("moblin")) {
          this.health -= 35;
        } else {
          this.health -= 1;
        }
      }
      this.tookDamageRecently = true;
      invFrame++;
    }
  }
  
  public void display(){
    
    if ((invFrame > 0) && (invFrame <= invulnerabilityFrames)){
      invFrame++;
      
      tint(0, 0, 0, 200);
      
      if (invFrame >= invulnerabilityFrames) {
        this.invFrame = 0;
        this.tookDamageRecently = false;
      }
    }
    this.enemyAnimate.display(this.x,this.y);
    noTint();
  }
  // randomly generates coordinates as long as they arent within terrain
  public void spawn(ArrayList<Obstacle> obstacles, ArrayList<Border> borders, ArrayList<Enemy> enemies) {  
    PVector[] position = getPosition();
    while (collidingWithObstacle(obstacles, borders, position) || collidingWithOtherEnemies(enemies, position)){
      this.x = random(spriteSize,width-spriteSize);
      this.y = random(spriteSize,height-spriteSize);
      position = getPosition();
    }    
  }
  
  public boolean collidingWithAttack(ArrayList<Attack> attacks, PVector[] currentPosition) {
    
    for (PVector vertex : currentPosition) {
      for (Attack attack : attacks) {
        if (attack.isColliding(vertex.x, vertex.y)) {
          return true;
        }
      }
    }
    return false;
    
  }
  
  public boolean collidingWithShield(ArrayList<Shield> shields, PVector[] currentPosition) {
    
    for (PVector vertex : currentPosition) {
      for (Shield shield : shields) {
        if (shield.isColliding(vertex.x, vertex.y)) {
          return true;
        }
      }
    }
    return false;
    
  }
  
  public boolean collidingWithBoomerang(ArrayList<Boomerang> boomerangs, PVector[] currentPosition) {
    
    for (PVector vertex : currentPosition) {
      for (Boomerang boomerang : boomerangs) {
        if (boomerang.isColliding(vertex.x, vertex.y)) {
          return true;
        }
      }
    }
    return false;
    
  }
  
  //colliding with a polygon
  public boolean collidingWithObstacle(ArrayList<Obstacle> obstacles, ArrayList<Border> borders, PVector[] currentPosition) {
    // checking each vertex in the current position of the enemy
    for (PVector vertex : currentPosition) {
      // for every vertex, check if it collides with every obstacle
      for (Obstacle obstacle: obstacles) {
        // if there is collision, return true
        if (obstacle.isColliding(vertex.x, vertex.y)){
          return true;
        }
      }
      // check if vertex collides with a border
      for (Border border: borders) {
        if (border.isColliding(vertex.x, vertex.y)) {
          return true;
        }
      }
    }
    return false;
  }
  
  public boolean collidingWithOtherEnemies(ArrayList<Enemy> enemies, PVector[] currentPosition) {
    for (PVector vertex: currentPosition) {
      for (Enemy enemy: enemies) {
        if (enemy.isColliding(vertex.x, vertex.y)) {
          return true;
        }
      }
    }
     return false; 
  }
  
  // moves enemy back and forth in X
  public void moveX(ArrayList<Obstacle> obstacles, ArrayList<Border> borders, ArrayList<Enemy> enemies,
  ArrayList<Attack> attacks, ArrayList<Shield> shields, ArrayList<Boomerang> boomerangs){
    Animation[] animationsX = new Animation[2];
    animationsX[0]=enemyRight;
    animationsX[1]=enemyLeft;
    count++;
    
    PVector[] position = this.getPosition();
    if (move > 0) { // moving right
      position[1].x += move;
      position[2].x += move;
    } else { // moving left
      position[0].x += move;
      position[3].x += move;
    }
    // slow enemy if attacked
    if ((collidingWithAttack(attacks, position) && !tookDamageRecently)
    || (collidingWithBoomerang(boomerangs, position) && !tookDamageRecently)) {
      this.x -= move/2;
      
    }
    if (!collidingWithObstacle(obstacles, borders, position) 
    && !collidingWithOtherEnemies(enemies,  position) 
    && !collidingWithShield(shields, position)) {
      this.x = this.x+move;
    }

    
    if ((count==100)||(this.x>=(width-this.w/2))||(this.x<=this.w/2)){
      index = index + increment;
      increment = increment * -1;
      this.enemyAnimate=animationsX[index];
      move = move * -1;
      count=0;
    }
  }
 
  public void moveY(ArrayList<Obstacle> obstacles, ArrayList<Border> borders, ArrayList<Enemy> enemies, 
  ArrayList<Attack> attacks, ArrayList<Shield> shields, ArrayList<Boomerang> boomerangs){
    Animation[] animationsY = new Animation[2];
    animationsY[0]=enemyDown;
    animationsY[1]=enemyUp;
    count++;
    
    PVector[] position = this.getPosition();
    if (move > 0) { // moving down
      position[2].y += move;
      position[3].y += move;
    } else { // moving up
      position[0].y += move;
      position[1].y += move;
    }
    // slow enemy if attacked
    if ((collidingWithAttack(attacks, position) && !tookDamageRecently) 
    || (collidingWithBoomerang(boomerangs, position) && !tookDamageRecently)){
      this.y -= move/2;
    }
    if (!collidingWithObstacle(obstacles, borders, position) 
    && !collidingWithOtherEnemies(enemies, position) 
    && !collidingWithShield(shields, position)) { 
      this.y = this.y+move;
    }
    
    if ((count==100)||(this.y>=(height-this.h/2))||(this.y<=this.h/2)){
      index = index + increment;
      increment = increment * -1;
      this.enemyAnimate=animationsY[index];
      move = move * -1;
      count=0;
    }
  }
  
  public PVector[] getPosition() {
    PVector[] allVertices = new PVector[4];
    // top left corner
    allVertices[0] = new PVector(this.x, this.y);
    // top right corner
    allVertices[1] = new PVector(this.x + spriteSize, this.y);
    // bottom right corner
    allVertices[2] = new PVector(this.x + spriteSize, this.y + spriteSize);
    // bottom left corner
    allVertices[3] = new PVector(this.x, this.y + spriteSize);
    
    return allVertices;
  } 
  
  
  public boolean isColliding(float px, float py) {
    
    boolean collision = false;
    PVector[] vertices = getPosition();
    
    int next = 0;
    for (int current=0; current<vertices.length; current++) {
  
      next = current+1;
      // wrap to first vertex
      if (next == vertices.length) { 
        next = 0;
      }
      
      PVector vc = vertices[current];    
      PVector vn = vertices[next]; 
      
      // check if in bounds
      if (((vc.y >= py && vn.y < py) || (vc.y < py && vn.y >= py)) &&
           (px < (vn.x-vc.x)*(py-vc.y) / (vn.y-vc.y)+vc.x)) {
              collision = !collision;
      }
    }
    return collision;
  } 
   
}
class Heart {
  float x, y;
  boolean isFull, isHalf, isEmpty;
  PImage full, half, empty;
  float health;
  
  Heart(float x, float y) {
    this.health = 1;
    full = loadImage("./sprites/life/fullHeart.png");
    half = loadImage("./sprites/life/halfHeart.png");
    empty = loadImage("./sprites/life/emptyHeart.png");
    full.resize(2*full.width, 2*full.height);
    half.resize(2*half.width, 2*half.height);
    empty.resize(2*empty.width, 2*empty.height);
    this.isFull = true;
    this.isHalf = false;
    this.isEmpty = false;
    this.x = x;
    this.y = y;
  }
  
  public void display() {
    if (isFull) {
      image(full, x, y);
    } else if (isHalf) {
      image(half, x, y);
    } else {
      image(empty, x, y);
    }
  }
  
  public void loseHalf() {
    
    health -= 0.5f;
    
    if (abs(health - 0.5f) < EPSILON) {
      isFull = false;
      isHalf = true;
    } else {
      isHalf = false;
      isEmpty = true;
    }
    
  }
  
}
class Heirarchy{
 float x, y, fairy_xSpeed, fairy_ySpeed, fairyX, fairyY, fairy2X, fairy2Y;
 int w, h;
 PImage triforce, fairy, fairy2;
 int count;
  
 Heirarchy(float x, float y){
    this.x=x;
    this.y=y;
    this.w=200;
    this.h=200;
    this.fairyX=this.x-50;
    this.fairyY=this.y-10;
    this.fairy_xSpeed=10;
    this.fairy_ySpeed=6;
    this.triforce=loadImage("triforce.png");
    this.triforce.resize(this.w,this.h);
    this.fairy=loadImage("./sprites/Fairy.gif");
    this.fairy.resize(30,45);
    this.fairy2=loadImage("./sprites/Fairy.gif");
    this.fairy2.resize(30,45);
    
    this.count=0;
 }
  
 public void display(){
   image(this.triforce,this.x,this.y); 
   pushMatrix();
   image(fairy,fairyX,fairyY);
   //image(fairy2,fairy2X,fairy2Y);
   popMatrix();
   
  }
   
  //makes it bounce around the screen
  public void move(){
    
    this.fairyX += this.fairy_xSpeed;
    this.fairyY += this.fairy_ySpeed;
    this.fairy2X+= this.fairy_xSpeed;
    this.fairy2Y+= this.fairy_ySpeed;
    
    if (this.fairyX > this.x+this.w){
      this.fairy_xSpeed = -this.fairy_xSpeed;
    }
    if (this.fairyY > this.y+this.h){
      this.fairy_ySpeed = -this.fairy_ySpeed;
    }
    
    if (this.fairyX < this.x-50){
      this.fairy_xSpeed = -this.fairy_xSpeed;
    }
    if (this.fairyY < this.y-10){
      this.fairy_ySpeed = -this.fairy_ySpeed;
    }
  }
}
class Life {
  ArrayList<Heart> hearts;
  PImage full, half, empty;
  int maxHearts = 4;
  int currentHearts;
  boolean tookDamageRecently, isShielded;
  
  Life() {
    this.currentHearts = 3;
    hearts = new ArrayList<Heart>();
    int spaceFactor = 30;
    for (int i = 0; i < currentHearts; i++) {
      hearts.add(new Heart(195 + spaceFactor*i, 70));
    }
    this.tookDamageRecently = false;
  }
  
  public void display() {
    for (Heart heart: hearts) {
      heart.display();
    }
  }
  
  public boolean takeDamage() {
    if (!tookDamageRecently && !isShielded) {
      for (int i = hearts.size()-1; i > -1; i--) {
        // find first heart that has health larger than 0
        if (hearts.get(i).health > 0) {
          
          hearts.get(i).loseHalf();
          return true;
        }
      }
    }
    return false;
    
  }
  
  public void shield() {
    this.isShielded = true;
  }
  
  public void unshield() {
    this.isShielded = false;
  }
  
  public boolean isEmpty() {
    return (hearts.get(0).isEmpty);
  }
  
  
}
class Link {
  Life health;
  float w,h,x,y, attackX, attackY;
  int c;
  String weapon, ranged;
  PImage upIdle, downIdle, leftIdle, rightIdle, image;
  Animation linkUp, linkDown, linkLeft, linkRight, linkAnimate, attackUp, attackDown, attackLeft, attackRight,
  whiteUp, whiteDown, whiteLeft, whiteRight, attackAni;
  PFont zeldaFont = createFont("HyliaSerifBeta-Regular.otf", 30);
  boolean isWalking, isAttacking;
  
  Attack attack;
  boolean hasAttacked, isShielding, hasShielded, hasThrownBoomerang; 
  String direction; 
  int killCount; 
  
  float spriteSize = 32;
  float weaponRange = 30;
  float shieldRange = 5;
  float incrementSize = 6; 
  
  float invulnerabilityFrame = 100;
  float invFrame = 0;
  PImage killCounter;
  
  Link(float x, float y){
    this.w = spriteSize;
    this.h = spriteSize;
    this.x = x;
    this.y = y;
    this.attackX=x;
    this.attackY=y+h/2;
    this.linkUp = new Animation("./sprites/link/LinkUp", 2);
    this.linkDown = new Animation("./sprites/link/LinkDown", 2);
    this.linkLeft = new Animation("./sprites/link/LinkLeft", 2);
    this.linkRight = new Animation("./sprites/link/LinkRight", 2);
    this.linkAnimate = this.linkUp;
    
    this.attackUp = new Animation("./sprites/attack/upAttack", 3);
    this.attackDown = new Animation("./sprites/attack/downAttack", 3);
    this.attackLeft = new Animation("./sprites/attack/leftAttack", 3);
    this.attackRight = new Animation("./sprites/attack/rightAttack", 3);
    
    this.whiteUp = new Animation("./sprites/attack/upWhite", 3);
    this.whiteDown = new Animation("./sprites/attack/downWhite", 3);
    this.whiteLeft = new Animation("./sprites/attack/leftWhite", 3);
    this.whiteRight = new Animation("./sprites/attack/rightWhite", 3);
    
    this.attackAni = this.attackDown;
    this.direction = "down";
    this.hasAttacked = false;
    this.hasShielded = false;
    this.killCount = 0;
    
    this.upIdle=loadImage("./sprites/link/LinkUp0.gif");
    this.downIdle=loadImage("./sprites/link/LinkDown0.gif");
    this.leftIdle=loadImage("./sprites/link/LinkLeft0.gif");
    this.rightIdle=loadImage("./sprites/link/LinkRight0.gif");
    this.image = this.downIdle;
    this.weapon = "default";
    this.ranged = "default";
    this.c = color(255,0,0);
    
    this.health = new Life();
    this.killCounter = loadImage("./sprites/skull.jpg");
    this.killCounter.resize(75, 120);
    this.isWalking = false;
    this.isAttacking = false;
  }
  
  public void display() {
    // display all of link's hitboxes
    //displayHitbox();
    //displayAttack();
    //displayShield();
    
    displayKills();
    this.health.display();
    performInvFrames(); // will be invulnerable if needed
    highlightWeapon();
    
    if (isWalking) {
      animateWalk();
    }
    else if (isAttacking) {
      animateAttack();
    } else {
      image(this.image, this.x, this.y);
    }
    
    noTint();// so invulnerability frames dont make the entire screen flash red
  }
  
  public void isWalking() {
    this.isWalking = true;
  }
  
  public void isShielding() {
    this.isShielding = true;
  }
  
  public void isAttacking() {
    this.isAttacking = true;
  }
  
  public void animateWalk() {
    this.linkAnimate.display(this.x,this.y);
  }
  
  public void animateAttack() {
    this.attackAni.display(this.attackX,this.attackY);
  }
  
  public void displayHitbox() {
    PVector[] position = this.getPosition();
    rectMode(CORNER);
    fill(255);
    rect(position[0].x, position[0].y, this.w, this.h);
    noFill();
  }
  
  public void displayKills() {
    
    image(killCounter, 750, 5);
    textFont(zeldaFont, 30);
    fill(0xffffd80d);
    textAlign(CENTER);
    text(""+killCount, 840, 78);
    noFill();
  }
  
  public void highlightWeapon() {
    PShape weaponHighlight = createShape();
    noFill();
    weaponHighlight.beginShape();
    weaponHighlight.strokeWeight(5);
    weaponHighlight.stroke(0xffffd80d);
    if (this.weapon.equals("default")) {
      
      weaponHighlight.vertex(400, 35);//near the letter
      weaponHighlight.vertex(390, 35);//top left
      weaponHighlight.vertex(390, 105); //bottom left
      weaponHighlight.vertex(442, 105); // bottom right
      weaponHighlight.vertex(442, 35); // top right
      weaponHighlight.vertex(430, 35); // top right near letter
      weaponHighlight.endShape();
    } else {
      
      weaponHighlight.vertex(485, 35);//near the letter
      weaponHighlight.vertex(475, 35);//top left
      weaponHighlight.vertex(475, 105); //bottom left
      weaponHighlight.vertex(527, 105); // bottom right
      weaponHighlight.vertex(527, 35); // top right
      weaponHighlight.vertex(513, 35); // top right near letter
      weaponHighlight.endShape();
    }
    shape(weaponHighlight, 0, 0);
    
    noStroke();
    
    
  }
  
  public void performInvFrames() {
    if ((invFrame > 0) && (invFrame < invulnerabilityFrame)){
      invFrame++;
      if (invFrame % 15 == 0) {
        tint(255, 0, 0, 255);
      } else {
        noTint();
      }
      if (invFrame == invulnerabilityFrame) {
        this.invFrame = 0;
        this.health.tookDamageRecently = false;
        noTint();
      }
    }
  }
  
  public void takeDamage() {
    
    if (invFrame == 0) {
      if (health.takeDamage()) {
        if (!health.isShielded) {
          invFrame++;
        }
      }
    }
    
  }
  
  //used to display the attack hitbox/range
  public void displayAttack() {
    PVector[] vertices = getAttackPosition();
    PShape attack;
    
    attack = createShape();
    attack.beginShape();
    attack.fill(255, 200);
    for (int vertex = 0; vertex < vertices.length; vertex++) {
      attack.vertex(vertices[vertex].x, vertices[vertex].y);
    }
    attack.endShape(CLOSE);
    shape(attack, 0, 0);
    
  }
  
  //used to display the shield hitbox/range
  public void displayShield() {
    PVector[] vertices = getShieldPosition();
    PShape shield;
    
    shield = createShape();
    shield.beginShape();
    shield.fill(34,139,34, 200);
    for (int vertex = 0; vertex < vertices.length; vertex++) {
      shield.vertex(vertices[vertex].x, vertices[vertex].y);
    }
    shield.endShape(CLOSE);
    shape(shield, 0, 0);
    
  }
  
  public boolean isDead() {
    return health.isEmpty();
  }
  
  public void up(Map map){
  
    this.linkAnimate=this.linkUp;
    this.image=this.upIdle;
    PVector[] position = this.getPosition();
    position[0].y -= incrementSize;
    position[1].y -= incrementSize;
    // running into enemies?
    if (map.isCollidingWithEnemies(position)) {
      takeDamage();
    }
    // running into obstacle?
    if (!map.isCollidingWithObstacles(position)){
      this.y = this.y-incrementSize;
    } 
    // running into border?
    else if (map.reachedBorder(position)) {
      map.loadNextScene();
      this.y = 700;
    } 
  
  };
  
  
  public void down(Map map){
    this.linkAnimate=this.linkDown;
    this.image=this.downIdle;
    
    PVector[] position = this.getPosition();
    position[2].y += incrementSize;
    position[3].y += incrementSize;
    
    if (map.isCollidingWithEnemies(position)) {
      takeDamage();
    }
    if (!map.isCollidingWithObstacles(position)){
      this.y = this.y+incrementSize;
    } else if (map.reachedBorder(position)) {
      map.loadNextScene();
      this.y = 130;
    }
    
  };
  
  public void left(Map map){
    this.linkAnimate=this.linkLeft;
    this.image=this.leftIdle;
    
    PVector[] position = this.getPosition();
    position[0].x -= incrementSize;
    position[3].x -= incrementSize;
    
    if (map.isCollidingWithEnemies(position)) {
      takeDamage();
    }
    // hitting terrain?
    if (!map.isCollidingWithObstacles(position)){
      this.x = this.x-incrementSize;
    } 
    // reached border?
    else if (map.reachedBorder(position)) {
      map.loadNextScene();
      if (map.currentScene == 0){
        this.y = 450;
      }
      this.x = 910;
    } 
    
  };
  
  public void right(Map map){
    this.linkAnimate=this.linkRight;
    this.image=this.rightIdle;
    
    PVector[] position = this.getPosition();
    position[1].x += incrementSize;
    position[2].x += incrementSize;
    
    // hitting enemies?
    if (map.isCollidingWithEnemies(position)) {
      takeDamage();
    }
    if (!map.isCollidingWithObstacles(position)){
      this.x = this.x+incrementSize;
    } else if (map.reachedBorder(position)) {
      map.loadNextScene();
      if (map.currentScene == 0){
        this.y = 440;
      }
      this.x = 70;
    } 
    
  };
  
  public PVector[] getPosition() {
    //rectangle around link's sprite
    PVector[] allVertices = new PVector[4];
    // top left corner
    allVertices[0] = new PVector(this.x, this.y);
    // top right corner
    allVertices[1] = new PVector(this.x + spriteSize, this.y);
    // bottom right corner
    allVertices[2] = new PVector(this.x + spriteSize, this.y + spriteSize);
    // bottom left corner
    allVertices[3] = new PVector(this.x, this.y + spriteSize);
    
    return allVertices;
  }
  
  public PVector[] getAttackPosition() {
    PVector[] attackPosition = getPosition();
    if (direction.equals("down")) {
      for (PVector coord : attackPosition) {
        coord.add(0, weaponRange);
      }
    } else if (direction.equals("up")) {
      for (PVector coord : attackPosition) {
        coord.add(0, -weaponRange);
      }
    } else if (direction.equals("left")) {
      for (PVector coord : attackPosition) {
        coord.add(-weaponRange, 0);
      }
    } else {
      for (PVector coord : attackPosition) {
        coord.add(weaponRange, 0);
      }
    }
    return attackPosition;  
  }
  
  public void update(Map map) {
    
    PVector[] position = getPosition();
    //println("am updating");
    if (map.isCollidingWithEnemies(position)) {
      //println("enemy collided with me");
      takeDamage();
    }
    if (isShielding) {
      shield(map);
      
    }
    if (map.boomerangReturned()) {
      this.hasThrownBoomerang = false;
    }
    if (map.hasKilledAnEnemy()) {
      killCount++;
    }
    
  }
  
  public PVector[] getShieldPosition() {
    PVector[] shieldPosition = getPosition();
    if (direction.equals("down")) {
      for (PVector coord : shieldPosition) {
        coord.add(0, shieldRange);
      }
    } else if (direction.equals("up")) {
      for (PVector coord : shieldPosition) {
        coord.add(0, -shieldRange);
      }
    } else if (direction.equals("left")) {
      for (PVector coord : shieldPosition) {
        coord.add(-shieldRange, 0);
      }
    } else {
      for (PVector coord : shieldPosition) {
        coord.add(shieldRange, 0);
      }
    }
    return shieldPosition;  
  }
  
  //creates an impenetrable shield on link
  public void shield(Map map) {
    // shield for the first time
    if (!hasShielded) {
      this.health.shield();
      map.addShieldObstacle(getShieldPosition());
      hasShielded = true;
    } else {
      //update shield position as moving 
      map.removeShieldObstacles();
      map.addShieldObstacle(getShieldPosition());
    }
  }
  
  public void unshield() {
    this.health.unshield();
  }
  
  public void attack(Map map){
    
    if (this.image==this.downIdle){
      //this.attackDirection = "down";
      if (this.weapon=="default"){
        this.attackAni=this.attackDown;
      }
      else if (this.weapon=="steel"){
        this.attackAni=this.whiteDown;
      }
      this.attackX=this.x;
      this.attackY=this.y+this.h/2-15;
    }
    else if (this.image==this.upIdle){
      //this.attackDirection = "up";
      if (this.weapon=="default"){
        this.attackAni=this.attackUp;
      }
      else if (this.weapon=="steel"){
        this.attackAni=this.whiteUp;
      }
      this.attackX=this.x;
      this.attackY=this.y-this.h/2-7;
    }
    else if(this.image==this.leftIdle){
      //this.attackDirection = "left";
      if (this.weapon=="default"){
        this.attackAni=this.attackLeft;
      }
      else if (this.weapon=="steel"){
        this.attackAni=this.whiteLeft;
      }
      this.attackX=this.x-this.w/2-7;
      this.attackY=this.y;
    }
    else if(this.image==this.rightIdle){
      //this.attackDirection = "right";
      if (this.weapon=="default"){
        this.attackAni=this.attackRight;
      }
      else if (this.weapon=="steel"){
        this.attackAni=this.whiteRight;
      }
      this.attackX=this.x+this.w/2-15;
      this.attackY=this.y;
    }
    
    // generate an obstacle that serves as an attack
    if (!hasAttacked) {
      map.addAttackObstacle(getAttackPosition(), this.weapon);
      hasAttacked = true;
    } 
    
  }
  
  public void throwBoomerang() {
    if (!hasThrownBoomerang) {
      println("tossing boomerang " + direction);
      map.addBoomerangObstacle(getAttackPosition(), "default", direction);
      hasThrownBoomerang = true;
    }
  }
  
  //can adjust the needed kill count to win
  public boolean hasWon() {
    return (this.killCount >= 20);
  }
  
  
}
class Map {
  
  Scene[] map;
  int currentScene;
  PVector[] heroPosition;
  Border collidingBorder;
  JSONObject mapdata;
  boolean sceneLoaded;
  
  Map (int numMaps) {
    mapdata = loadJSONObject("./maps/mapdata.json");
    this.map = new Scene[numMaps];
    for (int scene = 0; scene < map.length; scene++ ){
    map[scene] = new Scene("./maps/scene" + scene/10 + scene + ".png");
    }
    this.currentScene = 0;
    this.collidingBorder = null;
    sceneLoaded = false;
    //loadScene();
  }
     
  public void loadScene() {
    //dont load if already loaded
    if (!sceneLoaded) {
      
      println("loading scene " + currentScene);
      JSONObject scenedata = mapdata.getJSONObject("scenes").getJSONObject(""+currentScene);
        
        if (scenedata != null) { //ensuring JSON isnt broken
          
          int numBorders = scenedata.getJSONObject("borders").getInt("number");
          
          for (int i = 0; i < numBorders; i++) {
            
            JSONArray verticesObject = scenedata.getJSONObject("borders").getJSONObject("border" + i).getJSONArray("vertices");
            int sceneToLoad = scenedata.getJSONObject("borders").getJSONObject("border" + i).getInt("scene");
            int[] vertices = verticesObject.getIntArray();

            // getting x, y coordinates
            PVector[] border = new PVector[vertices.length/2];
            int j = 0;
            int index = 0;
            // add border vertices
            while (j < vertices.length) {
              border[index] = new PVector(vertices[j], vertices[j+1]);
              j += 2;
              index++;
            }
            
            map[currentScene].addBorder(border, sceneToLoad);            
          }
          
          int numObstacles = scenedata.getJSONObject("obstacles").getInt("number");
          
          for (int i = 0; i < numObstacles; i++) {
            JSONArray verticesObject = scenedata.getJSONObject("obstacles").getJSONObject("obstacle" + i).getJSONArray("vertices");
            int[] vertices = verticesObject.getIntArray();
            //println(vertices);
           
            PVector[] obstacles = new PVector[vertices.length/2];
            int j = 0;
            int index = 0;
            
            while (j < vertices.length) {
              obstacles[index] = new PVector(vertices[j], vertices[j+1]);
              j += 2;
              index++;
            }
            map[currentScene].addObstacle(obstacles); 
          }
          //generate enemies
          int numEnemies = scenedata.getJSONObject("enemies").getInt("number");
          for (int i = 0; i < numEnemies; i++) {
            map[currentScene].addEnemy();
          }
          
          sceneLoaded = true;
        } else {}//nothing to load
    }
    
  }
  //display the map, enemies, and terrain
  public void render() {
    map[currentScene].render();
  }
  
  public void addAttackObstacle(PVector[] position, String attackType) {
    map[currentScene].addAttack(position, attackType);
  }
  public void addShieldObstacle(PVector[] position) {
    map[currentScene].addShield(position);
  }
  public void addBoomerangObstacle(PVector[] position, String boomerangType, String direction) {
    map[currentScene].addBoomerang(position, boomerangType, direction);
  }
  public void removeAttackObstacles() {
    map[currentScene].removeAttack();
  }
  public void removeShieldObstacles() {
    map[currentScene].removeShield();
  }
  public boolean boomerangReturned() {
    return map[currentScene].boomerangReturned;
  }
  
  public boolean hasKilledAnEnemy() {
    boolean hasKilled = (map[currentScene].deadEnemies.size() > 0 );
    map[currentScene].removeDeadEnemies();
    return hasKilled;
  }
  
  // colliding with obstacles or enemies?
  public boolean isCollidingWithObstacles(PVector[] position) {
    for (PVector vertex : position) {
      if (map[currentScene].isCollidingWithObstacles(vertex.x, vertex.y)) {
        return true;
      }
    }
    // border is also considered a special obstacle
    return reachedBorder(position);
  }
  
  public boolean isCollidingWithEnemies(PVector[] position) {
    for (PVector vertex : position) {
      if (map[currentScene].isCollidingWithEnemies(vertex.x, vertex.y)) {
        return true;
      }
    }
    return false;
  }
  
  // tests if a border was reached and processes what scene should be loaded
  public boolean reachedBorder(PVector[] position) {
    for (PVector vertex: position) {
      if (map[currentScene].reachedBorder(vertex.x, vertex.y)) {
        // sees which border to load the next scene from
        collidingBorder = map[currentScene].getCollidingBorder(vertex.x, vertex.y);
        return true;
      }
    }
    return false;
  }
  // load the next scene
  public void loadNextScene() {
    //wipe enemies
    map[currentScene].clearAll();

    currentScene = collidingBorder.getNextScene();
    this.sceneLoaded = false;
  }
  
}
class Obstacle {
 
  PVector[] vertices;
  float spriteSize;
  
  //rectangular shape
  Obstacle(PVector[] vert) {
    this.vertices = vert.clone();
    this.spriteSize = 40;
  }
  // reference for polygon - point collision http://jeffreythompson.org/collision-detection/poly-point.php
  public boolean isColliding(float px, float py) {
    
    boolean collision = false;

    int next = 0;
    for (int current=0; current<vertices.length; current++) {
  
      next = current+1;
      // wrap to first vertex
      if (next == vertices.length) { 
        next = 0;
      }
      PVector vc = vertices[current];    
      PVector vn = vertices[next];
      
      // check if in bounds
      if (((vc.y >= py && vn.y < py) || (vc.y < py && vn.y >= py)) &&
           (px < (vn.x-vc.x)*(py-vc.y) / (vn.y-vc.y)+vc.x)) {
              collision = !collision;
      }
    }
    return collision;
  }
  
  public void display() {
    
    PShape obstacle;
    obstacle = createShape();
    obstacle.beginShape();
    obstacle.fill(255);
    for (int vertex = 0; vertex < this.vertices.length; vertex++) {
      obstacle.vertex(vertices[vertex].x, vertices[vertex].y);
    }
    obstacle.endShape(CLOSE);
    shape(obstacle, 0, 0);
  }
  
  public void printVertices() {
    for (int vertex = 0; vertex < this.vertices.length; vertex++) {
      println(vertices[vertex].x + " " + vertices[vertex].y);
    }
    print();
    
  }
  
}
class Scene {
  
  PImage scene;
  int sceneIndex;
  ArrayList<Obstacle> obstacles;
  ArrayList<Enemy> enemies;
  ArrayList<Enemy> deadEnemies;
  ArrayList<Border> borders;
  ArrayList<Attack> attacks; // should only ever contain 1 or 0 elements
  ArrayList<Shield> shields;
  ArrayList<Boomerang> boomerangs;
  boolean boomerangReturned, useOtherColor;
  
  float shieldX, shieldY, shieldDX, shieldDY, shieldCounter;
  String enemyType;
  ArrayList<String> enemyTypes = new ArrayList<String>();
  
  Scene(String sceneName) {
    
    this.sceneIndex = parseInt(sceneName.substring(12, 14));
   
    this.scene = loadImage(sceneName);
    
    this.obstacles = new ArrayList<Obstacle>();
    this.enemies = new ArrayList<Enemy>();
    this.borders = new ArrayList<Border>();
    this.attacks = new ArrayList<Attack>();
    this.shields = new ArrayList<Shield>();
    this.boomerangs = new ArrayList<Boomerang>();
    this.boomerangReturned = true;
    
    this.deadEnemies = new ArrayList<Enemy>();
    
    enemyTypes.add("blueOktorok");
    enemyTypes.add("redOktorok");
    enemyTypes.add("moblin");
    this.shieldX = 0; 
    this.shieldY = 0;
    this.shieldDX = 1;
    this.shieldDY = 0;
    this.shieldCounter = 0;
  }
  
  public void addBorder(PVector[] vertices, int sceneToLoad) {
    borders.add(new Border(vertices, sceneToLoad));
    
  }
  public void clearAll() {
    clearEnemies();
    removeAttack();
    removeShield();
    removeBoomerang();
  }
  
  public void clearEnemies() {
    enemies = new ArrayList<Enemy>();
    removeDeadEnemies();
  }
  
  public void addEnemy() {
    this.enemyType=enemyTypes.get(PApplet.parseInt(random(0,3)));
    enemies.add(new Enemy(obstacles, borders, enemies, this.enemyType));
  }
  
  
  public void addObstacle(PVector[] vertices) {
    obstacles.add(new Shield(vertices));
  }
  
  public void addAttack(PVector[] vertices, String attackType) {
    attacks.add(new Attack(vertices, attackType));
  }
  
  public void addShield(PVector[] vertices) {
    shields.add(new Shield(vertices));
  }
  
  public void addBoomerang(PVector[] vertices, String boomerangType, String direction) {
    boomerangReturned = false;
    boomerangs.add(new Boomerang(vertices, boomerangType, direction));
  }
  
  public void removeAttack() {
    attacks = new ArrayList<Attack>();
  }
  public void removeShield() {
    shields = new ArrayList<Shield>();
  }
  public void removeBoomerang() {
    boomerangs = new ArrayList<Boomerang>();
  }
  // eliminate dead enemies buffer 
  public void removeDeadEnemies() {
    deadEnemies = new ArrayList<Enemy>();
  }
  
  public void displayObstacles() {
    
    for (Obstacle obstacle: obstacles) {
      obstacle.display();
    }
    
  }
  
  public boolean isCollidingWithObstacles(float x, float y) {
    //tests if colliding with obstacles
    for (Obstacle obstacle: obstacles) {
      if (obstacle.isColliding(x, y)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean isCollidingWithEnemies(float x, float y) {
     // tests if colliding with enemies
    for (Enemy enemy: enemies) {
      if (enemy.isColliding(x, y) && !enemy.isDead()) {
        //println("checking if im colliding");
        return true; 
      }
    }
    return false;
  }
  
  public boolean reachedBorder(float x, float y) {
    for (Border border: borders) {
      if (border.isColliding(x, y)) {
        return true;
      }
    }
    return false;
  }
  
  public Border getCollidingBorder(float x, float y) {
    // seeing which border is colliding
    for (Border border: borders) {
      // getting scene index from colliding border
      if (border.isColliding(x, y)) {
        return border;
      }
    }
    return null;
  }
  // updates DX and DY to make a square around link as he's shielded
  public void updateShieldPosition() {
    shieldX += shieldDX;
    shieldY += shieldDY;
   
    if (shieldX + shields.get(0).vertices[0].x > shields.get(0).vertices[0].x + 25) {
      shieldDX = 0;
      shieldDY = 1;
    } 
    if (shieldY + shields.get(0).vertices[0].y > shields.get(0).vertices[0].y + 45) {
      shieldDX = -1;
      shieldDY = 0;
    }
    if (shieldX + shields.get(0).vertices[0].x  < shields.get(0).vertices[0].x - 10) { 
      shieldDX = 0;
      shieldDY = -1;
    }
    if (shieldY + shields.get(0).vertices[0].y < shields.get(0).vertices[0].y) {
      shieldDX = 1;
      shieldDY = 0;
      
      shieldX = -10;
      shieldY = 0;
    }
    
  }
    
  public void render() {
    image(scene, 0, 0);
    int counter = 0;
    shieldCounter++;
    // can maybe add attack effects here (displays attack hitbox)
    //if (attacks.size() > 0) {
      
    //  attacks.get(0).display();
    //}
    // can maybe add shield effects here (displays shield hitbox)
    if (shields.size() > 0) {
      //shields.get(0).display();
      if (shieldCounter % 25 == 0) {
        useOtherColor = !useOtherColor;
      }
      if (useOtherColor) {
        tint(255,0,0, 100);
      } else { tint(0,255,0, 100); }
      shields.get(0).shieldAura(shieldX, shieldY);
      updateShieldPosition();
      noTint();
    }
    if (boomerangs.size() > 0) {
      
      boomerangs.get(0).displayBoomerang();
      boomerangs.get(0).updateBoomerangPosition();
      
      if (boomerangs.get(0).hasReturned()) {
        removeBoomerang();
        boomerangReturned = true;
      }
    }
    //used to see collision detection
    //displayObstacles();
    // display the enemies and make them move
    for (Enemy enemy: enemies) {
      
      if (!enemy.isDead()){
        // check if enemy should be damaged
        enemy.update(attacks, boomerangs);
        enemy.display();
        //array containing data of the other enemies (so they dont collide)
        ArrayList<Enemy> otherEnemies = new ArrayList<Enemy>(enemies);
        otherEnemies.remove(counter);
        if (counter % 2 == 0) {
          enemy.moveX(obstacles, borders, otherEnemies, attacks, shields, boomerangs);
        } else {
          enemy.moveY(obstacles, borders, otherEnemies, attacks, shields, boomerangs);
        }
      } else {
        if (!enemies.get(counter).markedDead){
          deadEnemies.add(enemies.get(counter));
          enemies.get(counter).markDead();
        }
        //display some death animation?
        //this.killedAnEnemy = true;
        // enemy.playDead()(once)
      }
      counter++;
    }
  }
  
}
class Shield extends Obstacle {
  PImage shield;
  float shieldRange = 30;
  
  
  Shield(PVector[] position) {
    super(position); 
    shield = loadImage("./sprites/items/shield.png");
    shield.resize(15, 20);
  }
  public void display() {
    
    PShape obstacle;
    obstacle = createShape();
    obstacle.beginShape();
    obstacle.fill(34,139,34, 200);
    for (int vertex = 0; vertex < this.vertices.length; vertex++) {
      obstacle.vertex(vertices[vertex].x, vertices[vertex].y);
    }
    obstacle.endShape(CLOSE);
    shape(obstacle, 0, 0);
  }
  
  public void shieldAura(float dx, float dy) {
    //imageMode(CORNER);
    pushMatrix();
    translate(this.vertices[0].x + dx, this.vertices[0].y - 20 + dy);
    image(shield, 0, 0);
    popMatrix();  
  }
}
  public void settings() {  size(1000, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "zeldaGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
