To play: 

Open zeldaGame.pde in processing. If you do not have the sound library, Go to the sketch>import library>add library tab. 
Search for the Sound library by the processing foundation and import it.
Once complete, Press the play button in the upper left corner.

Controls: 
	To move: arrow up, down, left, right to move Link.

	NOTE: currently if you mouseclick in the gameplay screen, your character will die. This will be fixed for the final submission.
	
		